﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TrainingCoursesApp.data;
using TrainingCoursesApp.pageApp.pageListener;

namespace TrainingCoursesApp.pageApp.pageListener
{
    /// <summary>
    /// Логика взаимодействия для PageListenerCourse.xaml
    /// </summary>
    public partial class PageListenerCourse : Page
    {
        public int peopleID;
        public PageListenerCourse(int idPeople)
        {
            InitializeComponent();
            peopleID = idPeople;
            ClassDataBase.trainingCourses.UpdateCourseHoursPeopleCount();
            ClassDataBase.trainingCourses.UpdateStatusInProcess();
            ClassDataBase.trainingCourses.UpdateStatusEnd();
            ClassDataBase.trainingCourses.SaveChanges();
            lvCourse.ItemsSource = ClassDataBase.trainingCourses.Course.ToList();
        }

        private void btnOut_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lvCourse.SelectedItems.Count == 1)
                {
                    MessageBoxResult result = MessageBox.Show($"Вы действительно хотите выйти из курса?", "Предупреждение", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                    if (result == MessageBoxResult.Yes)
                    {
                        Course course = lvCourse.SelectedItem as Course;
                        ClassDataBase.trainingCourses.DeleteCoursePeople(course.CourseID, peopleID);
                        ClassDataBase.trainingCourses.SaveChanges();
                        lvCourse.ItemsSource = ClassDataBase.trainingCourses.Course.ToList();
                    }
                    else
                    {
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("Выберите один курс для выхода", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                lvCourse.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnIn_Click(object sender, RoutedEventArgs e)
        {
            Course course = lvCourse.SelectedItem as Course;
            ClassDataBase.trainingCourses.AddCoursePeople(course.CourseID, peopleID);
            ClassDataBase.trainingCourses.UpdateCourseHoursPeopleCount();
            ClassDataBase.trainingCourses.UpdateStatusInProcess();
            ClassDataBase.trainingCourses.UpdateStatusEnd();
            ClassDataBase.trainingCourses.SaveChanges();
            lvCourse.ItemsSource = ClassDataBase.trainingCourses.Course.ToList();
        }

        private void btnCertificate_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Будет добавлено в версии приложения 2.0", "Оповещение", MessageBoxButton.OK, MessageBoxImage.Asterisk);
            return;
        }

        private void lvCourse_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lvCourse.SelectedIndex == -1)
            {
                return;
            }
            else
            {
                int course = (lvCourse.SelectedItem as Course).CourseID;
                CoursePeople coursePeople = ClassDataBase.trainingCourses.CoursePeople.FirstOrDefault(x => x.IDCourse == course && x.IDPeople == peopleID);
                if ((lvCourse.SelectedItem as Course).IDStatus == 2 || (lvCourse.SelectedItem as Course).IDStatus == 3 || coursePeople != null)
                    btnIn.IsEnabled = false;
                if (coursePeople == null || (lvCourse.SelectedItem as Course).IDStatus == 3)
                    btnOutCourse.IsEnabled = false;
                if ((lvCourse.SelectedItem as Course).IDStatus != 3 ||  coursePeople == null)
                    btnCertificate.IsEnabled = false;
            }
        }
    }
}
