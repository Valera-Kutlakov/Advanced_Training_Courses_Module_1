﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TrainingCoursesApp.data;
using TrainingCoursesApp.pageApp.pageAdmin;

namespace TrainingCoursesApp.pageApp.pageAdmin
{
    /// <summary>
    /// Логика взаимодействия для PageAdminOrganizationEditAdd.xaml
    /// </summary>
    public partial class PageAdminOrganizationEditAdd : Page
    {
        public int id = 0;

        public PageAdminOrganizationEditAdd()
        {
            InitializeComponent();

            Title = "Добавление организации";
        }

        public PageAdminOrganizationEditAdd(Organization organization)
        {
            InitializeComponent();
            Title = "Изменение организации";
            id = organization.OrganizationID;
            txbxTitle.Text = organization.Title;
            txbxRegion.Text = organization.Region;
            txbxCity.Text = organization.City;
            txbxStreet.Text = organization.Street;
            txbxHouse.Text = organization.House;
            txbxCorpus.Text = organization.Corpus.ToString();
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (id == 0)
            {
                try
                {
                    Organization organization = new Organization()
                    {
                         Title = txbxTitle.Text,
                         Region = txbxRegion.Text,
                         City = txbxCity.Text,
                         Street = txbxStreet.Text,
                         House = txbxHouse.Text,
                         Corpus = int.Parse(txbxCorpus.Text)
                    };
                    ClassDataBase.trainingCourses.Organization.Add(organization);
                    ClassDataBase.trainingCourses.SaveChanges();
                    ClassFrame.frame.GoBack();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                try
                {
                    ClassDataBase.trainingCourses.UpdateOrganization(id, txbxTitle.Text, txbxRegion.Text, txbxCity.Text, txbxStreet.Text, txbxHouse.Text, int.Parse(txbxCorpus.Text));
                    ClassDataBase.trainingCourses.SaveChanges();
                    ClassFrame.frame.GoBack();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }
}
