﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TrainingCoursesApp.data;
using TrainingCoursesApp.pageApp.pageAdmin;

namespace TrainingCoursesApp.pageApp.pageAdmin
{
    /// <summary>
    /// Логика взаимодействия для PageAdminCourseDetail.xaml
    /// </summary>
    public partial class PageAdminCourseDetail : Page
    {
        public int idCourse;
        public int idOrganization;
        public PageAdminCourseDetail(int id)
        {
            InitializeComponent();

            idCourse = id;
            idOrganization = ClassDataBase.trainingCourses.Course.First(x => x.CourseID == idCourse).IDOrganization;

            lvCourseDetail.ItemsSource = ClassDataBase.trainingCourses.CourseEducatorTopic.Where(x => x.IDCourse == idCourse).ToList();

            cmbTopic.ItemsSource = ClassDataBase.trainingCourses.Topic.ToList();
            cmbTopic.SelectedValuePath = "TopicID";
            cmbTopic.DisplayMemberPath = "Title";

            cmbEducator.ItemsSource = ClassDataBase.trainingCourses.EducatorFIO(idOrganization).ToList();
            cmbEducator.SelectedValuePath = "EducatorID";
            cmbEducator.DisplayMemberPath = "EducatorName";
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                CourseEducatorTopic courseEducatorTopic = new CourseEducatorTopic()
                {
                    IDCourse = idCourse,
                    IDEducator = int.Parse(cmbEducator.SelectedValue.ToString()),
                    IDTopic = (cmbTopic.SelectedItem as Topic).TopicID
                };
                ClassDataBase.trainingCourses.CourseEducatorTopic.Add(courseEducatorTopic);
                ClassDataBase.trainingCourses.UpdateCourseHoursPeopleCount();
                ClassDataBase.trainingCourses.UpdateStatusInProcess();
                ClassDataBase.trainingCourses.UpdateStatusEnd();
                ClassDataBase.trainingCourses.SaveChanges();
                cmbEducator.SelectedIndex = -1;
                cmbTopic.SelectedIndex = -1;
                lvCourseDetail.ItemsSource = ClassDataBase.trainingCourses.CourseEducatorTopic.Where(x => x.IDCourse == idCourse).ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lvCourseDetail.SelectedItems.Count > 0)
                {
                    MessageBoxResult result = MessageBox.Show($"Вы действительно хотите удалить {lvCourseDetail.SelectedItems.Count} запись(-и)?", "Предупреждение", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                    if (result == MessageBoxResult.Yes)
                    {
                        for (int i = 0; i < lvCourseDetail.SelectedItems.Count;)
                        {
                            CourseEducatorTopic courseEducatorTopic = lvCourseDetail.SelectedItems[i] as CourseEducatorTopic;
                            if (courseEducatorTopic != null)
                            {
                                ClassDataBase.trainingCourses.CourseEducatorTopic.Remove(courseEducatorTopic);
                                ClassDataBase.trainingCourses.SaveChanges();
                                lvCourseDetail.ItemsSource = ClassDataBase.trainingCourses.CourseEducatorTopic.Where(x => x.IDCourse == idCourse).ToList();
                            }
                            else
                            {
                                return;
                            }
                        }
                        lvCourseDetail.SelectedIndex = -1;
                        MessageBox.Show("Удаление успешно завершено", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    if (result == MessageBoxResult.No) return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnPeople_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frame.Navigate(new PageAdminCoursePeople(idCourse));
        }
    }
}
