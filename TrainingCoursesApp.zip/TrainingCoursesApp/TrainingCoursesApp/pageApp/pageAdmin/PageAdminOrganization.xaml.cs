﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TrainingCoursesApp.data;
using TrainingCoursesApp.pageApp.pageAdmin;

namespace TrainingCoursesApp.pageApp.pageAdmin
{
    /// <summary>
    /// Логика взаимодействия для PageAdminOrganization.xaml
    /// </summary>
    public partial class PageAdminOrganization : Page
    {
        public PageAdminOrganization()
        {
            InitializeComponent();

            lvOrganization.ItemsSource = ClassDataBase.trainingCourses.Organization.ToList();
        }

        private void btnAddOrganization_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frame.Navigate(new PageAdminOrganizationEditAdd());
        }

        private void btnEditOrganization_Click(object sender, RoutedEventArgs e)
        {
            if (lvOrganization.SelectedItems.Count > 1)
            {
                MessageBox.Show("Выделите только один объект из списка", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            if (lvOrganization.SelectedItems.Count == 1)
                ClassFrame.frame.Navigate(new PageAdminOrganizationEditAdd(lvOrganization.SelectedItem as Organization));
        }

        private void btnDeleteOrganization_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lvOrganization.SelectedItems.Count > 0)
                {
                    MessageBoxResult result = MessageBox.Show($"Вы действительно хотите удалить {lvOrganization.SelectedItems.Count} запись(-и)?", "Предупреждение", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                    if (result == MessageBoxResult.Yes)
                    {
                        for (int i = 0; i < lvOrganization.SelectedItems.Count;)
                        {
                            Organization organization = lvOrganization.SelectedItems[i] as Organization;
                            if (organization != null)
                            {
                                ClassDataBase.trainingCourses.Organization.Remove(organization);
                                ClassDataBase.trainingCourses.SaveChanges();
                                lvOrganization.ItemsSource = ClassDataBase.trainingCourses.Organization.ToList();
                            }
                            else
                            {
                                return;
                            }
                        }
                        lvOrganization.SelectedIndex = -1;
                        MessageBox.Show("Удаление успешно завершено", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    if (result == MessageBoxResult.No) return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            lvOrganization.SelectedIndex = -1;
            lvOrganization.ItemsSource = ClassDataBase.trainingCourses.Organization.ToList();
        }
    }
}
