﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TrainingCoursesApp.data;
using TrainingCoursesApp.pageApp.pageAdmin;

namespace TrainingCoursesApp.pageApp.pageAdmin
{
    /// <summary>
    /// Логика взаимодействия для PageAdminCoursePeople.xaml
    /// </summary>
    public partial class PageAdminCoursePeople : Page
    {
        public int id;
        public PageAdminCoursePeople(int idCourse)
        {
            InitializeComponent();
            id = idCourse;
            lvPeople.ItemsSource = ClassDataBase.trainingCourses.PeopleFIO(idCourse).ToList();
            lvPeople.SelectedValuePath = "PeopleID";
        }

        private void btnOut_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lvPeople.SelectedItems.Count == 1)
                {
                    MessageBoxResult result = MessageBox.Show($"Вы действительно хотите выгнать участника?", "Предупреждение", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                    if (result == MessageBoxResult.Yes)
                    {
                        int idPeople = Convert.ToInt32(lvPeople.SelectedValue);
                        People people = ClassDataBase.trainingCourses.People.FirstOrDefault(x => x.PeopleID == idPeople);
                        ClassDataBase.trainingCourses.People.Remove(people);
                        ClassDataBase.trainingCourses.SaveChanges();
                        lvPeople.ItemsSource = ClassDataBase.trainingCourses.PeopleFIO(id).ToList();
                    }
                    else
                    {
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("Выберите одного участника", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                lvPeople.SelectedIndex = -1;
                MessageBox.Show("Участник успешно выгнан", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnCertificate_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Будет добавлено в версии приложения 2.0", "Оповещение", MessageBoxButton.OK, MessageBoxImage.Asterisk);
            return;
        }
    }
}
